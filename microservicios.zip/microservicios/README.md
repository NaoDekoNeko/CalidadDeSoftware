# Testing de microservicios con pytest

Haciendo uso del repo: `https://github.com/CrissUD/Microservicios_Contenedores_Calculadora`

Se le ha implementado una unidad de pruebas tanto con el cliente de pruebas de `Flask` como con llamadas al API.

El propósito de los test es demostrar la importancia, utilidad e impacto que tienen en la calidad del software

# Examen Final del curso Calidad de Software